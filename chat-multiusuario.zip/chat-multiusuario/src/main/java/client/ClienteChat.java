package client;

import java.io.*;
import java.net.Socket;
import java.nio.charset.StandardCharsets;

/** Cliente de console: uma thread lê do servidor, a principal lê o teclado. */
public class ClienteChat {

    public static void main(String[] args) {
        String host = args.length > 0 ? args[0] : "localhost";
        int porta = args.length > 1 ? Integer.parseInt(args[1]) : 5000;

        try (Socket socket = new Socket(host, porta);
             BufferedReader doServidor = new BufferedReader(
                     new InputStreamReader(socket.getInputStream(), StandardCharsets.UTF_8));
             PrintWriter paraServidor = new PrintWriter(new BufferedWriter(
                     new OutputStreamWriter(socket.getOutputStream(), StandardCharsets.UTF_8)), true);
             BufferedReader teclado = new BufferedReader(
                     new InputStreamReader(System.in, StandardCharsets.UTF_8))) {

            Thread receptor = new Thread(() -> {
                try {
                    String linha;
                    while ((linha = doServidor.readLine()) != null) System.out.println(linha);
                } catch (IOException ignored) {
                }
                System.out.println("Conexão encerrada.");
                System.exit(0);
            });
            receptor.setDaemon(true);
            receptor.start();

            String entrada;
            while ((entrada = teclado.readLine()) != null) {
                paraServidor.println(entrada);
                if (entrada.equalsIgnoreCase("/sair")) break;
            }
        } catch (IOException e) {
            System.err.println("Não foi possível conectar a " + host + ":" + porta + " - " + e.getMessage());
        }
    }
}
