package persistence;

import model.Mensagem;

import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Único ponto do sistema que fala SQL/JDBC. */
public class MensagemRepository {

    private final String url;

    public MensagemRepository(String url) {
        this.url = url;
        criarTabela();
    }

    private Connection conectar() throws SQLException {
        return DriverManager.getConnection(url);
    }

    private void criarTabela() {
        String sql = "CREATE TABLE IF NOT EXISTS mensagens ("
                + "id INTEGER PRIMARY KEY AUTOINCREMENT, "
                + "remetente VARCHAR(20) NOT NULL, "
                + "conteudo VARCHAR(500) NOT NULL, "
                + "horario VARCHAR(30) NOT NULL)";
        try (Connection c = conectar(); Statement st = c.createStatement()) {
            st.execute(sql);
        } catch (SQLException e) {
            throw new RuntimeException("Falha ao criar tabela de mensagens", e);
        }
    }

    /** synchronized: serializa escritas vindas de várias threads de clientes. */
    public synchronized void salvar(Mensagem m) {
        String sql = "INSERT INTO mensagens (remetente, conteudo, horario) VALUES (?, ?, ?)";
        try (Connection c = conectar(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, m.getRemetente());
            ps.setString(2, m.getConteudo());
            ps.setString(3, m.getHorario().toString());
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Falha ao salvar mensagem", e);
        }
    }

    /** Retorna as últimas n mensagens, da mais antiga para a mais recente. */
    public synchronized List<Mensagem> buscarUltimas(int n) {
        String sql = "SELECT remetente, conteudo, horario FROM mensagens ORDER BY id DESC LIMIT ?";
        List<Mensagem> lista = new ArrayList<>();
        try (Connection c = conectar(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, n);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    lista.add(new Mensagem(rs.getString("remetente"), rs.getString("conteudo"),
                            LocalDateTime.parse(rs.getString("horario"))));
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException("Falha ao buscar histórico", e);
        }
        Collections.reverse(lista);
        return lista;
    }
}
