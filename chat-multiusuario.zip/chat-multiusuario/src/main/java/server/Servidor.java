package server;

import persistence.MensagemRepository;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

/** Aceita conexões e delega cada uma a uma thread ClienteHandler. */
public class Servidor {

    public static final int PORTA_PADRAO = 5000;

    private final int porta;
    private final GerenciadorClientes gerenciador = new GerenciadorClientes();
    private final MensagemRepository repositorio;

    public Servidor(int porta, MensagemRepository repositorio) {
        this.porta = porta;
        this.repositorio = repositorio;
    }

    public void iniciar() throws IOException {
        try (ServerSocket serverSocket = new ServerSocket(porta)) {
            System.out.println("Servidor de chat ouvindo na porta " + porta);
            while (true) {
                try {
                    Socket socket = serverSocket.accept();
                    Thread t = new Thread(new ClienteHandler(socket, gerenciador, repositorio));
                    t.setDaemon(true);
                    t.start();
                } catch (IOException e) {
                    System.err.println("Falha ao aceitar conexão: " + e.getMessage());
                }
            }
        }
    }

    public static void main(String[] args) throws IOException {
        int porta = args.length > 0 ? Integer.parseInt(args[0]) : PORTA_PADRAO;
        MensagemRepository repo = new MensagemRepository("jdbc:sqlite:chat.db");
        new Servidor(porta, repo).iniciar();
    }
}
