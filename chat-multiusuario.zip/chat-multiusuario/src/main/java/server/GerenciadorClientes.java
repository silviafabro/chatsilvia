package server;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Lista sincronizada de clientes ativos. Toda leitura/escrita passa pelo
 * monitor da própria lista, evitando race conditions entre as threads.
 */
public class GerenciadorClientes {

    private final List<Destinatario> clientes = Collections.synchronizedList(new ArrayList<>());

    /** Registra o cliente de forma atômica; falha se o nome já estiver em uso. */
    public boolean registrar(Destinatario d) {
        synchronized (clientes) {
            for (Destinatario c : clientes) {
                if (c.getNome().equalsIgnoreCase(d.getNome())) return false;
            }
            clientes.add(d);
            return true;
        }
    }

    public void remover(Destinatario d) {
        clientes.remove(d);
    }

    public int quantidade() {
        return clientes.size();
    }

    public List<String> nomes() {
        synchronized (clientes) {
            List<String> nomes = new ArrayList<>();
            for (Destinatario c : clientes) nomes.add(c.getNome());
            return nomes;
        }
    }

    /**
     * Envia o texto a todos. O bloco synchronized garante que duas mensagens
     * não se intercalem: todos recebem na mesma ordem. Clientes que falham
     * no envio são removidos sem afetar os demais.
     * @return quantidade de clientes que receberam
     */
    public int broadcast(String texto) {
        List<Destinatario> falhos = new ArrayList<>();
        int enviados = 0;
        synchronized (clientes) {
            for (Destinatario c : clientes) {
                if (c.enviar(texto)) enviados++;
                else falhos.add(c);
            }
            clientes.removeAll(falhos);
        }
        return enviados;
    }
}
