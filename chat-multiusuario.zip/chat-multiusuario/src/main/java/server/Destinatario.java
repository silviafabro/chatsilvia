package server;

/** Abstração de quem recebe mensagens (permite testar o broadcast sem rede). */
public interface Destinatario {
    String getNome();

    /** @return true se enviou com sucesso; false se a conexão falhou. */
    boolean enviar(String texto);
}
