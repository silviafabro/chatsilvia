package server;

import model.Mensagem;
import model.Usuario;
import persistence.MensagemRepository;

import java.io.*;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.List;

/** Atende uma única conexão de cliente, em sua própria thread. */
public class ClienteHandler implements Runnable, Destinatario {

    private static final int TAMANHO_HISTORICO = 20;

    private final Socket socket;
    private final GerenciadorClientes gerenciador;
    private final MensagemRepository repositorio;
    private BufferedReader entrada;
    private PrintWriter saida;
    private volatile String nome = "?";

    public ClienteHandler(Socket socket, GerenciadorClientes gerenciador, MensagemRepository repositorio) {
        this.socket = socket;
        this.gerenciador = gerenciador;
        this.repositorio = repositorio;
    }

    @Override
    public String getNome() { return nome; }

    @Override
    public synchronized boolean enviar(String texto) {
        if (saida == null) return false;
        saida.println(texto);
        return !saida.checkError();
    }

    @Override
    public void run() {
        boolean registrado = false;
        try {
            entrada = new BufferedReader(new InputStreamReader(socket.getInputStream(), StandardCharsets.UTF_8));
            saida = new PrintWriter(new BufferedWriter(
                    new OutputStreamWriter(socket.getOutputStream(), StandardCharsets.UTF_8)), true);

            registrado = cadastrarNome();
            if (!registrado) return;

            enviarHistorico();
            gerenciador.broadcast("*** " + nome + " entrou no chat ***");

            String linha;
            while ((linha = entrada.readLine()) != null) {
                linha = linha.trim();
                if (linha.isEmpty()) continue;
                if (linha.equalsIgnoreCase("/sair")) break;
                if (linha.equalsIgnoreCase("/usuarios")) {
                    enviar("Online: " + String.join(", ", gerenciador.nomes()));
                    continue;
                }
                processarMensagem(linha);
            }
        } catch (IOException e) {
            System.out.println("Conexão com '" + nome + "' encerrada abruptamente: " + e.getMessage());
        } finally {
            if (registrado) {
                gerenciador.remover(this);
                gerenciador.broadcast("*** " + nome + " saiu do chat ***");
                System.out.println(nome + " desconectou. Online: " + gerenciador.quantidade());
            }
            fechar();
        }
    }

    private boolean cadastrarNome() throws IOException {
        enviar("Digite seu nome:");
        String tentativa;
        while ((tentativa = entrada.readLine()) != null) {
            if (!Usuario.nomeValido(tentativa)) {
                enviar("Nome inválido (2 a 20 caracteres: letras, números, _ ou -). Tente novamente:");
                continue;
            }
            Usuario u = new Usuario(tentativa);
            this.nome = u.getNome();
            if (gerenciador.registrar(this)) {
                enviar("Bem-vindo, " + nome + "! Comandos: /usuarios, /sair");
                System.out.println(nome + " conectou. Online: " + gerenciador.quantidade());
                return true;
            }
            enviar("Nome já em uso. Escolha outro:");
        }
        return false;
    }

    private void enviarHistorico() {
        List<Mensagem> historico = repositorio.buscarUltimas(TAMANHO_HISTORICO);
        enviar("--- Últimas mensagens ---");
        for (Mensagem m : historico) enviar(m.formatarHistorico());
        enviar("--- Fim do histórico ---");
    }

    private void processarMensagem(String texto) {
        try {
            Mensagem m = Mensagem.nova(nome, texto);
            repositorio.salvar(m);
            gerenciador.broadcast(m.formatar());
        } catch (IllegalArgumentException e) {
            enviar("Erro: " + e.getMessage());
        } catch (RuntimeException e) {
            enviar("Erro ao salvar a mensagem; tente novamente.");
            System.err.println("Erro de persistência: " + e.getMessage());
        }
    }

    private void fechar() {
        try { socket.close(); } catch (IOException ignored) { }
    }
}
