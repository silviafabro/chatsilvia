package model;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/** Mensagem do chat: remetente, conteúdo e horário. */
public class Mensagem {

    public static final int TAMANHO_MAX = 500;
    private static final DateTimeFormatter FORMATO_EXIBICAO = DateTimeFormatter.ofPattern("HH:mm:ss");
    private static final DateTimeFormatter FORMATO_DATA = DateTimeFormatter.ofPattern("dd/MM HH:mm:ss");

    private final String remetente;
    private final String conteudo;
    private final LocalDateTime horario;

    public Mensagem(String remetente, String conteudo, LocalDateTime horario) {
        if (remetente == null || remetente.isBlank())
            throw new IllegalArgumentException("Remetente obrigatório.");
        if (conteudo == null || conteudo.isBlank())
            throw new IllegalArgumentException("Mensagem vazia.");
        if (conteudo.length() > TAMANHO_MAX)
            throw new IllegalArgumentException("Mensagem excede " + TAMANHO_MAX + " caracteres.");
        if (horario == null)
            throw new IllegalArgumentException("Horário obrigatório.");
        this.remetente = remetente.trim();
        this.conteudo = conteudo.trim();
        this.horario = horario.withNano(0);
    }

    /** Cria mensagem com o horário atual. */
    public static Mensagem nova(String remetente, String conteudo) {
        return new Mensagem(remetente, conteudo, LocalDateTime.now());
    }

    /** Formato enviado aos clientes: [HH:mm:ss] nome: texto */
    public String formatar() {
        return "[" + horario.format(FORMATO_EXIBICAO) + "] " + remetente + ": " + conteudo;
    }

    /** Formato usado no histórico (inclui dia e mês). */
    public String formatarHistorico() {
        return "[" + horario.format(FORMATO_DATA) + "] " + remetente + ": " + conteudo;
    }

    public String getRemetente() { return remetente; }
    public String getConteudo() { return conteudo; }
    public LocalDateTime getHorario() { return horario; }
}
