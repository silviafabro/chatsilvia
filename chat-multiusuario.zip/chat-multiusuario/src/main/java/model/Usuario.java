package model;

import java.util.Objects;

/** Usuário do chat. O nome é validado na criação (regra de negócio). */
public class Usuario {

    public static final int TAMANHO_MIN = 2;
    public static final int TAMANHO_MAX = 20;

    private final String nome;

    public Usuario(String nome) {
        if (!nomeValido(nome)) {
            throw new IllegalArgumentException(
                "Nome inválido: use de " + TAMANHO_MIN + " a " + TAMANHO_MAX
                + " caracteres (letras, números, _ ou -).");
        }
        this.nome = nome.trim();
    }

    public static boolean nomeValido(String nome) {
        if (nome == null) return false;
        String n = nome.trim();
        return n.length() >= TAMANHO_MIN && n.length() <= TAMANHO_MAX
                && n.matches("[\\p{L}\\p{N}_-]+");
    }

    public String getNome() { return nome; }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Usuario)) return false;
        return nome.equalsIgnoreCase(((Usuario) o).nome);
    }

    @Override
    public int hashCode() { return Objects.hash(nome.toLowerCase()); }

    @Override
    public String toString() { return nome; }
}
