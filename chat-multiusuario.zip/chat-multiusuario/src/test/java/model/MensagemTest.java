package model;

import org.junit.jupiter.api.Test;
import java.time.LocalDateTime;
import static org.junit.jupiter.api.Assertions.*;

class MensagemTest {
    private final LocalDateTime t = LocalDateTime.of(2026, 10, 8, 14, 30, 15);

    @Test void formataComHorarioRemetenteEConteudo() {
        assertEquals("[14:30:15] Ana: Olá!", new Mensagem("Ana", "Olá!", t).formatar());
    }
    @Test void formatoDeHistoricoIncluiData() {
        assertEquals("[08/10 14:30:15] Ana: Olá!", new Mensagem("Ana", "Olá!", t).formatarHistorico());
    }
    @Test void rejeitaConteudoVazio() {
        assertThrows(IllegalArgumentException.class, () -> new Mensagem("Ana", "  ", t));
    }
    @Test void rejeitaConteudoMuitoLongo() {
        assertThrows(IllegalArgumentException.class,
                () -> new Mensagem("Ana", "x".repeat(Mensagem.TAMANHO_MAX + 1), t));
    }
    @Test void rejeitaRemetenteOuHorarioNulo() {
        assertThrows(IllegalArgumentException.class, () -> new Mensagem(null, "oi", t));
        assertThrows(IllegalArgumentException.class, () -> new Mensagem("Ana", "oi", null));
    }
    @Test void novaMensagemRegistraHorarioAtual() {
        LocalDateTime antes = LocalDateTime.now().withNano(0);
        Mensagem m = Mensagem.nova("Ana", "oi");
        assertFalse(m.getHorario().isBefore(antes));
    }
}
