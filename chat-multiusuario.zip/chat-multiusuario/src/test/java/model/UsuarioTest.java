package model;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class UsuarioTest {
    @Test void aceitaNomeValido() {
        assertEquals("Ana_01", new Usuario("  Ana_01 ").getNome());
    }
    @Test void rejeitaNomeVazioOuNulo() {
        assertFalse(Usuario.nomeValido(""));
        assertFalse(Usuario.nomeValido(null));
        assertThrows(IllegalArgumentException.class, () -> new Usuario("   "));
    }
    @Test void rejeitaNomeCurtoLongoOuComEspaco() {
        assertFalse(Usuario.nomeValido("a"));
        assertFalse(Usuario.nomeValido("a".repeat(21)));
        assertFalse(Usuario.nomeValido("joao silva"));
    }
    @Test void nomesIguaisIgnorandoMaiusculas() {
        assertEquals(new Usuario("Maria"), new Usuario("maria"));
    }
}
