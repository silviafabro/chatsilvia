package persistence;

import model.Mensagem;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Path;
import java.time.LocalDateTime;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

class MensagemRepositoryTest {

    @TempDir Path pasta;
    MensagemRepository repo;

    @BeforeEach void preparar() {
        repo = new MensagemRepository("jdbc:sqlite:" + pasta.resolve("teste.db"));
    }

    @Test void salvaERecuperaMensagem() {
        LocalDateTime t = LocalDateTime.of(2026, 10, 8, 10, 0, 0);
        repo.salvar(new Mensagem("Ana", "oi", t));
        List<Mensagem> r = repo.buscarUltimas(10);
        assertEquals(1, r.size());
        assertEquals("Ana", r.get(0).getRemetente());
        assertEquals("oi", r.get(0).getConteudo());
        assertEquals(t, r.get(0).getHorario());
    }

    @Test void buscarUltimasRespeitaLimiteEOrdem() {
        for (int i = 1; i <= 5; i++) repo.salvar(Mensagem.nova("Ana", "m" + i));
        List<Mensagem> r = repo.buscarUltimas(3);
        assertEquals(3, r.size());
        assertEquals("m3", r.get(0).getConteudo());
        assertEquals("m5", r.get(2).getConteudo());
    }

    @Test void historicoVazioRetornaListaVazia() {
        assertTrue(repo.buscarUltimas(10).isEmpty());
    }
}
