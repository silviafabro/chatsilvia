package server;

import org.junit.jupiter.api.Test;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.*;
import static org.junit.jupiter.api.Assertions.*;

class GerenciadorClientesTest {

    /** Cliente falso: guarda o que recebeu, sem rede. */
    static class Falso implements Destinatario {
        final String nome; final boolean falha;
        final List<String> recebidas = Collections.synchronizedList(new ArrayList<>());
        Falso(String nome, boolean falha) { this.nome = nome; this.falha = falha; }
        public String getNome() { return nome; }
        public boolean enviar(String t) { if (falha) return false; recebidas.add(t); return true; }
    }

    @Test void broadcastChegaATodos() {
        GerenciadorClientes g = new GerenciadorClientes();
        Falso a = new Falso("a1", false), b = new Falso("b1", false);
        g.registrar(a); g.registrar(b);
        assertEquals(2, g.broadcast("oi"));
        assertEquals(List.of("oi"), a.recebidas);
        assertEquals(List.of("oi"), b.recebidas);
    }

    @Test void rejeitaNomeDuplicado() {
        GerenciadorClientes g = new GerenciadorClientes();
        assertTrue(g.registrar(new Falso("Ana", false)));
        assertFalse(g.registrar(new Falso("ana", false)));
        assertEquals(1, g.quantidade());
    }

    @Test void clienteComFalhaEhRemovidoSemAfetarOsDemais() {
        GerenciadorClientes g = new GerenciadorClientes();
        Falso ok = new Falso("ok", false), ruim = new Falso("ruim", true);
        g.registrar(ok); g.registrar(ruim);
        assertEquals(1, g.broadcast("msg"));
        assertEquals(1, g.quantidade());
        assertEquals(List.of("msg"), ok.recebidas);
    }

    @Test void removerDiminuiQuantidade() {
        GerenciadorClientes g = new GerenciadorClientes();
        Falso a = new Falso("a1", false);
        g.registrar(a); g.remover(a);
        assertEquals(0, g.quantidade());
    }

    @Test void broadcastConcorrenteNaoPerdeMensagens() throws Exception {
        GerenciadorClientes g = new GerenciadorClientes();
        Falso a = new Falso("a1", false), b = new Falso("b1", false);
        g.registrar(a); g.registrar(b);
        int threads = 8, porThread = 200;
        ExecutorService ex = Executors.newFixedThreadPool(threads);
        CountDownLatch inicio = new CountDownLatch(1);
        for (int i = 0; i < threads; i++) {
            final int id = i;
            ex.submit(() -> {
                try { inicio.await(); } catch (InterruptedException e) { return; }
                for (int j = 0; j < porThread; j++) g.broadcast("t" + id + "-" + j);
            });
        }
        inicio.countDown();
        ex.shutdown();
        assertTrue(ex.awaitTermination(10, TimeUnit.SECONDS));
        assertEquals(threads * porThread, a.recebidas.size());
        assertEquals(a.recebidas, b.recebidas, "todos devem receber na mesma ordem");
    }

    @Test void registroConcorrenteComMesmoNomeAceitaApenasUm() throws Exception {
        GerenciadorClientes g = new GerenciadorClientes();
        ExecutorService ex = Executors.newFixedThreadPool(10);
        List<Future<Boolean>> r = new ArrayList<>();
        for (int i = 0; i < 10; i++) r.add(ex.submit(() -> g.registrar(new Falso("igual", false))));
        int aceitos = 0;
        for (Future<Boolean> f : r) if (f.get()) aceitos++;
        ex.shutdown();
        assertEquals(1, aceitos);
    }
}
