-- Script de criação da tabela de mensagens (SQLite)
CREATE TABLE IF NOT EXISTS mensagens (
    id        INTEGER PRIMARY KEY AUTOINCREMENT,
    remetente VARCHAR(20)  NOT NULL,
    conteudo  VARCHAR(500) NOT NULL,
    horario   VARCHAR(30)  NOT NULL  -- ISO-8601, ex.: 2026-10-08T14:30:15
);
